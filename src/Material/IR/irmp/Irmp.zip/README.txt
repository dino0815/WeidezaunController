IRMP - Infrared Multi Protocol Decoder
--------------------------------------

Version IRMP:  1.9.0  18.01.2010
Version IRSND: 1.9.0  18.01.2010

Dokumentation:
 
   http://www.mikrocontroller.net/articles/IRMP
