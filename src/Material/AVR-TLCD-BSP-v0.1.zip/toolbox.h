#ifndef TOOLBOX_H
#define TOOLBOX_H

//#include <stdlib.h>
//#include <stdio.h>
//#include <inttypes.h>
//#include <avr/interrupt.h>
#define F_CPU  16000000UL 
#define SYSCLK 16000000UL // timer clock 16Mhz
#include <avr/io.h>
#include <util/delay.h>

#define byte unsigned char
//typedef unsigned char byte;

//Port D:
#define RXD     0x01
#define TXD     0x02
#define Taster1 0x04
#define Taster2 0x08
#define Taster3 0x10
#define LED1    0x20
#define LED2    0x40
#define SUMMER  0x80

void init_ports(void);
void delay(long int count);
int sgn(int x);
void alarm(void);

#endif
